#include <xen/arm/hypercall.h>
